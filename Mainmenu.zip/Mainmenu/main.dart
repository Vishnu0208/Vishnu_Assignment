import 'dart:io';
import 'dart:math';

//  1) WORD FREQUENCY
void wordFrequency() {
  print("\nEnter text:");
  String text = stdin.readLineSync()!.toLowerCase();
  text = text.replaceAll(RegExp(r'[^\w\s]'), "");
  List words = text.split(" ");
  Map<String, int> freq = {};

  for (var w in words) {
    if (w.isNotEmpty) freq[w] = (freq[w] ?? 0) + 1;
  }

  freq.forEach((key, value) => print("$key - $value"));
}

//  2) BALANCED BRACKETS
bool isBalanced(String s) {
  List<String> stack = [];
  Map pairs = {')': '(', ']': '[', '}': '{'};

  for (var ch in s.split('')) {
    if (pairs.containsValue(ch))
      stack.add(ch);
    else if (pairs.containsKey(ch)) {
      if (stack.isEmpty || stack.removeLast() != pairs[ch]) return false;
    }
  }
  return stack.isEmpty;
}

void bracketsMenu() {
  print("\nEnter bracket string:");
  print(isBalanced(stdin.readLineSync()!) ? "Balanced" : "Not Balanced");
}

//  3) LIBRARY SYSTEM
List<String> books = [];

void libraryMenu() {
  while (true) {
    print("\n--- Library Menu ---");
    print("1 - Add Book\n2 - Search Book\n3 - Back");
    String choice = stdin.readLineSync()!;

    if (choice == "1") {
      print("Enter book name:");
      books.add(stdin.readLineSync()!);
      print("Book added.");
    } else if (choice == "2") {
      print("Search keyword:");
      String key = stdin.readLineSync()!;
      books.where((b) => b.contains(key)).forEach(print);
    } else if (choice == "3")
      break;
  }
}

//  4) LIS
int lis(List<int> arr) {
  List<int> temp = [];
  for (var x in arr) {
    int i = temp.indexWhere((e) => e >= x);
    (i == -1) ? temp.add(x) : temp[i] = x;
  }
  return temp.length;
}

void lisMenu() {
  print("\nEnter numbers separated by space:");
  List<int> list = stdin
      .readLineSync()!
      .split(" ")
      .map((e) => int.parse(e))
      .toList();

  print("LIS Length: ${lis(list)}");
}

//  5) URL SHORTENER
Map<String, String> urlMap = {};

String shortCode() {
  return Random().nextInt(999999).toString().padLeft(6, "0");
}

void urlMenu() {
  print("\n1 - Shorten URL\n2 - Redirect Code");
  String c = stdin.readLineSync()!;

  if (c == "1") {
    print("Enter URL:");
    String url = stdin.readLineSync()!;
    String code = shortCode();
    urlMap[code] = url;
    print("Shortened Code: $code");
  } else {
    print("Enter Code:");
    String code = stdin.readLineSync()!;
    print("URL -> ${urlMap[code] ?? "Not Found"}");
  }
}

// 6) CALCULATOR
List<String> history = [];

void calculator() {
  print("\nEnter: num1 operator num2 (Ex: 5 + 3)");
  String input = stdin.readLineSync()!;
  if (input == "history") {
    history.forEach(print);
    return;
  }

  var p = input.split(" ");
  double a = double.parse(p[0]), b = double.parse(p[2]);
  String op = p[1];

  double result = op == '+'
      ? a + b
      : op == '-'
      ? a - b
      : op == '*'
      ? a * b
      : a / b;
  String record = "$input = $result";
  history.add(record);
  print(record);
}
